#! /bin/sh

## set -x
source ../config.soft

XGEOMETRY="-geometry 70x12"
XTERM="xterm ${XGEOMETRY}"
## ==================================

${XTERM} -T wsnet -e "${WSNET} -F config -l wsnet.log"   &

C1=`run_console -o -l c1.log` 
C2=`run_console -o -l c2.log` 
sleep 1
sync

echo "consoles $C1 $C2"
echo "== Press the any key (enter) =============="
read 

## ==================================

TIME=$(( 30 * $FACTOR ))
EXTRA=echo

export SETUI="yes"

if [ "$1" == "debug1" ] ; then 
    WS1="`run_wsimnet_gdb 1 $DS1 wsn430-bal.elf $TIME $C1`" 
    EXTRA="msp430-insight wsn430-bal.elf"
else
    WS1="`run_wsimnet 1 $DS1 wsn430-bal.elf $TIME $C1`" 
fi 

if [ "$1" == "debug2" ] ; then
    WS2="`run_wsimnet_gdb 2 $DS2 wsn430-tst.elf $TIME $C2`"
    EXTRA="msp430-insight wsn430-tst.elf"
else
    WS2="`run_wsimnet 2 $DS2 wsn430-tst.elf $TIME $C2`"
fi 

echo "${WS1}"
echo "${WS2}"

${XTERM} -T wsim-1 -e "$WS1" &
${XTERM} -T wsim-2 -e "$WS2" &
${EXTRA} &

read

## ==================================
## ==================================

kill_demo

