#! /bin/sh

## set -x
source ../config.soft

## ==================================

xterm -T wsnet -e "${WSNET} -F config -l wsnet.log"   &

if [ "$1" != "stdout" ] ; then
    TC1=`run_console -l c1.log`
    TC2=`run_console -l c2.log`
    TC3=`run_console -l c3.log`

    echo "consoles $TC1 $TC2 $TC3"
    sync
    
    CC1="`tmp_console ${TC1}`"
    CC2="`tmp_console ${TC2}`"
    CC3="`tmp_console ${TC3}`"
else
    CC1=stdout
    CC2=stdout
    CC3=stdout
fi

echo "consoles $CC1 $CC2 $CC3"
echo "== Press the any key (enter) =============="
read 

## ==================================

export SETUI=yes
export SETESIMU=yes

TIME=$(( 20 * $FACTOR ))

WS1="`run_wsimnet 1 $DS1 wsn430-demo.elf $TIME $CC1`" 
WS2="`run_wsimnet 2 $DS2 wsn430-demo.elf $TIME $CC2`"
WS3="`run_wsimnet 3 $DS3 wsn430-demo.elf $TIME $CC3`"

echo "${WS1}"
echo "${WS2}"
echo "${WS3}"
xterm -T wsim-1 -e "$WS1" &
xterm -T wsim-2 -e "$WS2" &
xterm -T wsim-3 -e "$WS3" &

read

dump_trace n1
dump_trace n2
dump_trace n3

gnuplot < n1.gp
${WTRC} --in=n1.trc --out=n1.vcd --format=vcd
dump_esimu_trace n1 -p wsn430-demo.elf > esimu.log 2>&1

## ==================================
## ==================================

kill_demo
