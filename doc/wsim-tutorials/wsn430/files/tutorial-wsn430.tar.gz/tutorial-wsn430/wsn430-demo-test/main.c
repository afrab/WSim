
#include <io.h>
#include <signal.h>
#include <iomacros.h>
#include <stdio.h>
#include <string.h>

#include "leds.h"
#include "uart1.h"
#include "clock.h"
#include "timer.h"
#include "cc1100.h"
#include "cc1100_wsn430.h"
#include "ds2411.h"
#include "m25p80.h"

/* *********************
 * Global variables.
 * *********************/

volatile int red_led;
volatile int timer_wakeup;

#define SIZE 70 /* maximum packet size */

/* *********************
 * Interrupt handlers.
 * *********************/

volatile int port1_irq_gdo0_exit_lpm0 = 0;

interrupt (PORT1_VECTOR) port1_irq_handler(void)
{
  //printf("** Start irq port 1\n");
  if (P1IFG & (P1IE & GDO2BITMASK))
    {
      cc1100_interrupt_handler(CC1100_GDO2); 
      if (port1_irq_gdo0_exit_lpm0 == 1)
	{
	  LPM0_EXIT;
	}
    } 
  if (P1IFG & (P1IE & GDO0BITMASK))
    {
      cc1100_interrupt_handler(CC1100_GDO0); 
    }  
  //printf("** End irq port 1 %x\n", P1IFG);
  P1IFG = 0;
}


interrupt (PORT2_VECTOR) port2_irq_handler(void)
{
  printf("** interruption sur port 2 %x\n", P2IFG);
  P2IFG = 0;
}

interrupt (TIMERB1_VECTOR) timerb1_handler(void)
{
  LED_GREEN_ON;
  printf("timber b1\n");
}

interrupt (TIMERA1_VECTOR) timera1_handler(void)
{
  LED_GREEN_ON;
  printf("timber a1\n");
}

interrupt (DACDMA_VECTOR) dac_handler(void)
{
  LED_GREEN_ON;
  printf("dac\n");
}

interrupt (ADC12_VECTOR) adc12_handler(void)
{
  LED_GREEN_ON;
  printf("adc12\n");
}

interrupt (WDT_VECTOR) wdt_handler(void)
{
  LED_GREEN_ON;
  printf("wdt\n");
}

interrupt (COMPARATORA_VECTOR) compa_handler(void)
{
  LED_GREEN_ON;
  printf("comparatorA\n");
}

interrupt (USART1TX_VECTOR) usart1_tx_irq( void )
{
  LED_GREEN_ON;
  printf("usart1_tx\n");
}

interrupt (USART0TX_VECTOR) usart0_tx_irq(void)
{
  LED_GREEN_ON;
  printf("usart0_tx\n");
}

interrupt (USART0RX_VECTOR) usart0_rx_irq(void)
{
  LED_GREEN_ON;
  printf("usart0_rx\n");
}


/* *********************
 * timerA callback
 * *********************/

void timer_cb(void)
{
  if (red_led)
    LED_RED_OFF;
  else
    LED_RED_ON;
  red_led = 1 - red_led;
  timer_wakeup = 1;
}

/* *********************
 * Delay function.
 * *********************/

#define DELAY 0x100

void delay(unsigned int d) 
{
  int i,j;
  for(j=0; j < d; j++)
    {
      for (i = 0; i < 0xff; i++) 
	{
	  nop();
	  nop();
	}
    }
}

/* *********************
 * printf 
 * *********************/

int putchar(int c)
{
  return uart1_putchar(c);
}

/* *********************
 * Rx
 * *********************/

volatile int      rx_pkt_done;
volatile uint8_t *rx_pkt_data;
volatile int      rx_pkt_size;

void rx_packet_cb(uint8_t *rx_buffer, int size)
{
  rx_pkt_done = 1;
  rx_pkt_data = rx_buffer;
  rx_pkt_size = size;
}

void rx_packet_cb_up(void)
{
  switch (rx_pkt_size)
    {
    case 0:
      printf("recv: size = 0 !!\n");
      break;
    case -EEMPTY:
      printf("recv: empty packet\n");
      break;
    case -ERXFLOW:
      printf("recv: Rx overflow\n");
      break;
    case -ETXFLOW:
      printf("recv: Tx underrun ??\n");
      break;
    default:
      if (rx_pkt_size > 0)
	{
	  rx_pkt_data[rx_pkt_size] = 0;
	  printf("recv: %d, -%s-\n",rx_pkt_size,rx_pkt_data);
	}
      else
	{
	  printf("recv: error %d\n", rx_pkt_size);
	}
      break;
    }

  rx_pkt_data[0] = 0;
  cc1100_rx_enter();           /* back to rx           */
}

void rx_()
{
  char   rx_buffer[SIZE];

  /*
   * system has random locks if TimerA irq is enabled at
   * the same time as Rx, don't know why yet
   */
  /*
   * timerA3_register_callback(timer_cb);
   * timerA3_keep_active();
   * timerA3_ACLK_start_Hz(2);
   */

  port1_irq_gdo0_exit_lpm0 = 1;
  cc1100_calibrate();
  printf("ready...\n");

  /* Tx/Rx Fifo threshold, page 46
   * value   0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15
   * TX     61 57 53 49 45 41 37 33 29 25 21 17 13  9  5  1
   * RX      4  8 12 16 20 24 28 32 36 40 44 48 52 56 60 64
   */
  cc1100_set_fifo_threshold(14); 
  cc1100_set_manchester(CC1100_MANCHESTER_ENABLE);
  cc1100_set_data_whitening(CC1100_WHITEDATA_ENABLE);
  cc1100_set_calibration_policy(CC1100_CALIBRATION_TX_RX_IDLE);
  cc1100_set_rxoff_mode(CC1100_RXOFF_IDLE);
  cc1100_set_rx_packet_status(CC1100_STATUS_DISABLE);

  // cc1100_set_crc_policy(CC1100_CRC_ENABLE);
  // cc1100_set_rx_packet_status(CC1100_STATUS_ENABLE);
  cc1100_rx_register_buffer(rx_buffer,SIZE);
  cc1100_rx_register_rx_cb(rx_packet_cb);
  cc1100_rx_switch_mode(CC1100_RX_MODE_POLLING);
  //// cc1100_rx_switch_mode(CC1100_RX_MODE_IRQ);
  cc1100_rx_enter();

  while (1)
    {
      LPM0;
      if (rx_pkt_done == 1)
	{
	  LED_BLUE_ON;
	  rx_pkt_done  = 0;
	  timer_wakeup = 0;
	  rx_packet_cb_up();
	  LED_BLUE_OFF;
	}
      else if (timer_wakeup == 1)
	{
	  /* timer irq */
	}
      else
	{
	  printf("snd: don't know why I wake up\n");
	}
    }
}

/* *********************
 * Tx
 * *********************/

void tx_()
{
  char tx_buffer[SIZE];

  int id       = 0;
  red_led      = 0;
  timer_wakeup = 0;

  timerA3_register_callback(timer_cb);
  timerA3_keep_active();
  timerA3_ACLK_start_2S();

  cc1100_set_tx_power(CC1100_TX_POWER_CONFIG_30DBM);
  cc1100_set_manchester(CC1100_MANCHESTER_ENABLE);
  cc1100_set_data_whitening(CC1100_WHITEDATA_ENABLE);
  cc1100_set_calibration_policy(CC1100_CALIBRATION_TX_RX_IDLE);
  // cc1100_set_crc_policy(CC1100_CRC_ENABLE);

  cc1100_calibrate();
  printf("ready...\n");

#define IRQ_TX
#if defined(IRQ_TX)
  while (1)
    {
      cc1100_idle();
      LPM0;
      
      if (timer_wakeup == 1)
	{
	  int len;

	  timer_wakeup = 0;
	  sprintf(tx_buffer,"snd: echo %d // fill with data 1234567890 0987654321",id++);
	  len = strlen(tx_buffer);
	  len ++;
	  printf("%s : %d\n",tx_buffer,len);

	  LED_BLUE_ON;
	  cc1100_idle();
	  cc1100_utx(tx_buffer, len);
	  // cc1100_rx_enter();
	  LED_BLUE_OFF;
	}
      else
	{
	  printf("snd: don't know why I wake up\n");
	}
    }
#else
  while (1)
    {
      delay(4000);
      sprintf(tx_buffer,"snd: echo %d",id++);
      printf("%s\n",tx_buffer);
      LED_BLUE_ON;
      cc1100_idle();
      cc1100_utx(tx_buffer, strlen(tx_buffer));

      // *******************
      // cc1100_rx_enter();
      // *******************
      LED_BLUE_OFF;
    }
#endif
}

/* ************************
 * Flash
 * ************************/

void flash_test()
{
  unsigned char signature = 0xfa;
  unsigned char state     = 0xfb;

  signature = m25p80_init();
  state     = m25p80_get_state();
  m25p80_power_down();

  uart1_init();
  printf("m25p80_init      returned %x\n",signature);
  printf("m25p80_get_state returned %x\n",state);
}

/* ************************
 * ds2411
 * ************************/

void ds2411_test()
{
  ds2411_serial_number_t id; 

  switch (ds2411_init())
    {
    case DS2411_ERROR:
      printf("  ds2411_init() reports an error.\n");
      printf("  verify MCLK speed, should run at 8MHz\n");
      LPM4;
      break;
    case DS2411_SUCCESS:
      printf("  ds2411_init() ok.\n");
      break;
    }

  printf("  ds2411_get_id().\n");

  ds2411_get_id(&id);
  ds2411_print_id(&id);
}

/* *********************
 * main
 * *********************/

int main(void) 
{
  P1SEL  = 0x00;        // Selector         = 0:GPIO     1:peripheral
  P1DIR  = 0xff;        // Direction        = 0:input    1:output
  P1IE   = 0x00;        // Interrupt enable = 0:disable  1:enable
  P1IES  = 0x00;        // Edge select      = 0:L to H   1:H to L
  P1IFG  = 0x00;
  
  P2SEL  = 0x00;
  P2DIR  = 0xff;
  P2IE   = 0x00;
  P2IES  = 0x00;
  P2IFG  = 0x00;

  DMA0CTL &= (DMAEN | DMAIFG | DMAIE);
  DMA1CTL &= (DMAEN | DMAIFG | DMAIE);
  DMA2CTL &= (DMAEN | DMAIFG | DMAIE);

  /* leds */
  LEDS_INIT();
  LEDS_OFF();

  // set MCLK on XT2 at 8MHz
  set_mcu_speed_xt2_mclk_8MHz_smclk_1MHz();

  //set_timer();
  uart1_init();
  printf("UART init.\n");
  
  //
  ds2411_test();
  flash_test();

  // enable interrupts
  cc1100_init();
  printf("CC1100 init.\n");
  eint();          


#if defined(SENDER)
  printf("Worldsens test program, sender\n");
  tx_();
#elif defined(ECHO)
  printf("Worldsens test program, echo\n");
  rx_();
#else
#error must define SENDER or ECHO
#endif  

  return 0;
}
