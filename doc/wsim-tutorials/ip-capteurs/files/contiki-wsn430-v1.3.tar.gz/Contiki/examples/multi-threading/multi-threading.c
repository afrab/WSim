/*
 * Copyright (c) 2007, Swedish Institute of Computer Science.
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. Neither the name of the Institute nor the names of its contributors 
 *    may be used to endorse or promote products derived from this software 
 *    without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE. 
 *
 * This file is part of the Contiki operating system.
 * 
 * Author: Oliver Schmidt <ol.sc@web.de>
 *
 * $Id: multi-threading.c,v 1.4 2008/05/26 09:12:22 oliverschmidt Exp $
 */

/**
 * \file
 *         A very simple Contiki application showing how to use the Contiki
 *         Multi-threading library
 * \author
 *         Oliver Schmidt <ol.sc@web.de>
 */

/* The Contiki Multi-threading library is on Windows implemented using
 * Win32 fibers. The Cygwin C-library implements Thread-Local-Storage
 * in a way that is incompatible with fibers. Therefore most Cygwin
 * C-library functions don't work when called from a Contiki thread. */

#include <stdio.h>
#include <string.h>

#include "contiki.h"
#include "sys/log.h"
#include "sys/mt.h"

PROCESS(multi_threading_process, "Multi-threading process");
AUTOSTART_PROCESSES(&multi_threading_process);

  
/*---------------------------------------------------------------------------*/
static void thread_1(void *data)
{
  int i = 0;
  char *m;
  m = data;
  printf("thread 1 started, %s\n", m);
  while(1) { // loop with no interruption
    printf("%c",m[i]);
    i++;
    i %= strlen(m);
  }
  mt_exit();
}
/*---------------------------------------------------------------------------*/
static void thread_2(void *data)
{
  int i = 0, j;
  char *m;
  
  printf("data=%p\n", data);
  
  m = data;
  printf("thread 2 started, %s\n", m);
  while(1) { // loop with no interruption
    for (j=0; j<5; j++)
    {
        printf("%c",m[i]);
        i++;
        i %= strlen(m);
    }
    mt_yield(); // we've done enough, yield
  }
  mt_exit();
}
/*---------------------------------------------------------------------------*/
PROCESS_THREAD(multi_threading_process, ev, data)
{
  static struct mt_thread alpha_thread;
  static struct mt_thread count_thread;

  static struct etimer timer;
  static int toggle;

  static char d1[] = "JIHGFEDCBA";
  static char d2[] = "9876543210";
  
  PROCESS_BEGIN();
  
  mt_init(); // init the multithread module (does nothing)
  mt_start(&alpha_thread, thread_1, d1);
  mt_start(&count_thread, thread_2, d2);

  etimer_set(&timer, CLOCK_SECOND / 2);

  while(1) {
    printf("contiki thread\n");
    PROCESS_WAIT_EVENT();
    if(ev == PROCESS_EVENT_TIMER) {
      if(toggle) {
        printf("thread 1: ");
        mtarch_pstart(); // thread 1 doesn't yield, therefore start preemption
        mt_exec(&alpha_thread);
        printf("\n");
        toggle--;
      } else {
        printf("thread 2: "); // thread 2 will yield, no need for preemption
        mt_exec(&count_thread);
        printf("\n");
        toggle++;
      }
      etimer_set(&timer, CLOCK_SECOND / 2);
    }
  }
  
  mt_stop(&alpha_thread);
  mt_stop(&count_thread);
  mt_remove();

  PROCESS_END();
}
/*---------------------------------------------------------------------------*/
