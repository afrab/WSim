/* Copyright (c) 2006 by CITI Insa de Lyon.  All Rights Reserved */

/***
   NAME
     main
   PURPOSE
     
   NOTES
     
   HISTORY
     efleury - Sep 18, 2006: Created.
     $Log: main.c,v $
     Revision 1.3  2007-03-30 17:29:06  afraboul

     Wsim
     ====

     - event tracer  :
         - global TRACER_ID definitions in libtracer/tracer.h
           to avoid id reuse


     - energy tracer :
         - wrapper implementation
         - adding calls in relevent places on machine / mcu / devices
         - msp430 cpu modified to include etrace, eSimu + kcachegrind working
         - ne peripherals yet

     - devices/cc1100
         - tracer_event id changed

     - move LPM_SIGNAL with SIG_MCU_ signals
     - add pc_current() for current executing instruction pc() is only on an insn
       boundary at beginning of cycle


     WConsole
     ========
     - multithread I/O support
     - memory leak on screen_delete fixed



     examples
     ========
     - clean wsn430 examples to remove duplicated files

     - examples/wsn430-demo + examples/wsn430-cc1100
         code synchronisation to new llpi functions
         multi crystal 26MHz and 27MHz support

     llpi needs a clean implem

     Revision 1.2  2006-09-21 14:38:10  afraboul
     - driver modification, must invert input

     Revision 1.1  2006-09-21 11:58:23  efleury
     testing the LI-Polymer Charge Managment Controller

***/

#include <io.h>
#include <signal.h>
#include <iomacros.h>
#include <stdio.h>

#include "leds.h"
#include "mcp73861.h"
#include "clock.h"

/**********************
 * Delay function.
 **********************/

#define DELAY 0x800

void delay(unsigned int d) 
{
  int i,j;
  for(j=0; j < 0xff; j++)
    {
      for (i = 0; i<d; i++) 
	{
	  nop();
	  nop();
	}
    }
}

int led_blue_state;
void led_blue_toggle()
{
  if (led_blue_state == 0)
    LED_BLUE_ON;
  else
    LED_BLUE_OFF;
  led_blue_state = 1 - led_blue_state;
}

int led_green_state;
void led_green_toggle()
{
  if (led_green_state == 0)
    LED_GREEN_ON;
  else
    LED_GREEN_OFF;
  led_green_state = 1 - led_green_state;
}

int led_red_state;
void led_red_toggle()
{
  if (led_red_state == 0)
    LED_RED_ON;
  else
    LED_RED_OFF;
  led_red_state = 1 - led_red_state;
}

/**********************
 * main
 **********************/

int main(void) 
{
  enum mcp73861_result_t status;

  P1IE   = 0x00;        // Interrupt enable
  P2IE   = 0x00;        // 0:disable 1:enable

  
  set_mcu_speed_xt2_mclk_8MHz_smclk_1MHz();

  mcp73861_init();
  
  LEDS_INIT();
  LEDS_ON();
  delay(DELAY);
  LEDS_OFF();

  led_red_state   = 0;
  led_green_state = 0;
  led_blue_state  = 0;

  while (1) {
    led_blue_toggle();

    status = mcp73861_get_status();

    switch (status & MCP73861_STAT1){
    case MCP73861_STAT1 & MCP73861_OFF:
      LED_RED_OFF;
      break;
    case MCP73861_STAT1 & MCP73861_ON:
      LED_RED_ON;
      break;
    case MCP73861_STAT1 & MCP73861_FLASHING:
      led_red_toggle();
      break;
    }
    
    switch (status & MCP73861_STAT2){
    case MCP73861_STAT2 & MCP73861_OFF:
      LED_GREEN_OFF;
      break;
    case MCP73861_STAT2 & MCP73861_ON:
      LED_GREEN_ON;
      break;
    case MCP73861_STAT2 & MCP73861_FLASHING:
      led_green_toggle();
      break;
    }
  }
}
