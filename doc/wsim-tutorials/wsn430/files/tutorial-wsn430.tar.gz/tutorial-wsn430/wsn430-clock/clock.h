#ifndef CLOCK_H
#define CLOCK_H

void set_mcu_speed_dco_mclk_4MHz_smclk_1MHz();
void set_mcu_speed_xt2_mclk_4MHz_smclk_1MHz();
void set_mcu_speed_xt2_mclk_8MHz_smclk_1MHz();
void set_mcu_speed_xt2_mclk_8MHz_smclk_8MHz();

#endif
