#! /bin/sh

## set -x
source ../config.soft

## ==================================

TIME=$(( 30 * $FACTOR ))

WS1="`run_wsim $DS1 cc1100-27MHz.elf $TIME`" 

echo "${WS1}"
xterm -T wsim-1 -e "$WS1" &

read

## ==================================
## ==================================

kill_demo
