#! /bin/sh

## set -x
source ../config.soft

## ==================================
export SETUI=true
#C1=`run_console -l c1.log`
C1=stdout

sync
echo "consoles $C1"
echo "== Press the any key (enter) =============="
read 

## ==================================

TIME=$(( 7 * $FACTOR ))

WS1="`run_wsim $DS1 wsn430-m25p80.elf $TIME $C1`" 

echo "${WS1}"
xterm -T wsim-1 -e "$WS1" &

read

## ==================================
## ==================================

kill_demo

